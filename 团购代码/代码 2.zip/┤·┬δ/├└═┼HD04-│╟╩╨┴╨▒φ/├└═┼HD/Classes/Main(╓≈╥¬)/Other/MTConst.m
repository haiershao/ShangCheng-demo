#import <Foundation/Foundation.h>

NSString *const MTCityDidChangeNotification = @"MTCityDidChangeNotification";
NSString *const MTSelectCityName = @"MTSelectCityName";