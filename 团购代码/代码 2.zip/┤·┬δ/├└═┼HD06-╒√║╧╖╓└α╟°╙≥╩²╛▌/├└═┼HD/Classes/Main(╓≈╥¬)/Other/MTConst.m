#import <Foundation/Foundation.h>

NSString *const MTCityDidChangeNotification = @"MTCityDidChangeNotification";
NSString *const MTSelectCityName = @"MTSelectCityName";

NSString *const MTSortDidChangeNotification = @"MTSortDidChangeNotification";
NSString *const MTSelectSort = @"MTSelectSort";