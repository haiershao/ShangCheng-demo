//
//  MTDetailViewController.h
//  美团HD
//
//  Created by apple on 14/11/27.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MTDeal;
@interface MTDetailViewController : UIViewController
@property (nonatomic, strong) MTDeal *deal;
@end
