//
//  MTCitySearchResultViewController.h
//  美团HD
//
//  Created by apple on 14/11/24.
//  Copyright (c) 2014年 heima. All rights reserved.
//  显示城市搜索结果

#import <UIKit/UIKit.h>

@interface MTCitySearchResultViewController : UITableViewController
@property (nonatomic, copy) NSString *searchText;
@end
